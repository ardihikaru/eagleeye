from scheduler.app import SchedulerService

if __name__ == '__main__':
	app = SchedulerService()
	app.run()
