from .module import ResizerModule
